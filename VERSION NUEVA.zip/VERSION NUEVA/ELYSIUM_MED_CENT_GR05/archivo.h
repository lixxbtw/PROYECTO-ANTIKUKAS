#ifndef ARCHIVO_H_INCLUDED
#define ARCHIVO_H_INCLUDED
#include <cstdio>
#include <cstring>
#include <iostream>
#include "rlutil.h"
using namespace std;
using namespace rlutil;

template <class T>

class Archivo {
private:
    char nombre[30];
public:
    Archivo(const char* n = "") {
        nombre[0] = '\0';
        if (n) strncpy(nombre, n, sizeof(nombre)-1);
    }

    bool guardar(const T& reg) {
        FILE* p = fopen(nombre, "ab");
        if (!p) return false;
        bool ok = fwrite(&reg, sizeof(T), 1, p);
        fclose(p);
        return ok;
    }

    bool leer(T& reg, int pos) {
        FILE* p = fopen(nombre, "rb");
        if (!p) return false;
        fseek(p, pos * sizeof(T), SEEK_SET);
        bool ok = fread(&reg, sizeof(T), 1, p);
        fclose(p);
        return ok;
    }

    int cantidadRegistros() {
        FILE* p = fopen(nombre, "rb");
        if (!p) return 0;
        fseek(p, 0, SEEK_END);
        long bytes = ftell(p);
        fclose(p);
        return (bytes > 0 ? bytes / sizeof(T) : 0);
    }

    void listarTodos() {
        system("cls");
        setBackgroundColor(BLUE);
        setColor(WHITE);

        int n = cantidadRegistros();
        T obj;

        int x = rlutil::tcols() / 2 - 25;
        int y = rlutil::trows() / 2 - (n / 2) - 2;

        rlutil::locate(x, y);
        cout << "===============================================" << endl;
        rlutil::locate(x, y + 1);
        cout << "          LISTADO DE REGISTROS (TOTAL: " << n << ")" << endl;
        rlutil::locate(x, y + 2);
        cout << "===============================================" << endl;

        for (int i = 0; i < n; ++i) {
            if (leer(obj, i)) {
                rlutil::locate(x, y + 4 + i);
                cout << i + 1 << ". ";
                obj.mostrar();
            }
        }

        cout << endl;
        rlutil::locate(x, y + 5 + n);
        cout << "Presione ENTER para volver al menu...";
        cin.ignore();
        cin.get();
    }
};

#endif // ARCHIVO_H_INCLUDED
