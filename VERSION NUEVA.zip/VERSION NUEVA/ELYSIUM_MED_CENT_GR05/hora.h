#ifndef HORA_H_INCLUDED
#define HORA_H_INCLUDED

class Hora {
private:
    int hora;
    int minutos;
    int segundos;
public:
    Hora();
    void cargar();
    void mostrar() const;
};

#endif // HORA_H_INCLUDED
