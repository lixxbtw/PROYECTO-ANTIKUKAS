
#include <iostream>
#include "Paciente.h"
#include "Medico.h"
#include "Consultorio.h"
#include "Turno.h"
#include "FuncionesGenerales.h"

using namespace std;

void menuPacientes();
void menuMedicos();
void menuConsultorios();
void menuTurnos();

int main() {
    int opcion;
    do {
        cout << "=== SISTEMA DE GESTION CLINICA ===" << endl;
        cout << "1. Gestion de Pacientes" << endl;
        cout << "2. Gestion de Medicos" << endl;
        cout << "3. Gestion de Consultorios" << endl;
        cout << "4. Gestion de Turnos" << endl;
        cout << "0. Salir" << endl;
        cout << "Seleccione una opcion: ";
        cin >> opcion;
        system("cls");

        switch (opcion) {
        case 1: menuPacientes(); break;
        case 2: menuMedicos(); break;
        case 3: menuConsultorios(); break;
        case 4: menuTurnos(); break;
        case 0: cout << "Saliendo del sistema..." << endl; break;
        default: cout << "Opcion incorrecta." << endl; break;
        }
    } while (opcion != 0);
    return 0;
}
