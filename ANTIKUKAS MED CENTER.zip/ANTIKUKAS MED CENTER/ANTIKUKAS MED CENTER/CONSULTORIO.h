#ifndef CONSULTORIO_H
#define CONSULTORIO_H

#include <iostream>
using namespace std;

class Consultorio {
private:
    int id;
    int numero;
    int piso;
    char especialidad[30];
    bool activo;

public:
    // Metodos principales
    void cargar();
    void mostrar() const;

    // Getters
    int getNumero() const { return numero; }
    int getPiso() const { return piso; }
    const char* getEspecialidad() const { return especialidad; }
    bool getActivo() const { return activo; }

    // Setters
    void setActivo(bool estado) { activo = estado; }

    // Archivos
    bool guardarEnArchivo() const;
    bool leerDeArchivo(int pos);
};

// Funciones del menu Consultorios
void menuConsultorios();
void altaConsultorio();
void listarConsultorios();
void buscarConsultorioPorEspecialidad();
void buscarConsultorioPorPiso();
void bajaConsultorio();

#endif
