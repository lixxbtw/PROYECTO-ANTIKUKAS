#include <iostream>
#include <cstring>
#include <fstream>
#include "Paciente.h"
using namespace std;

const char* ARCHIVO_PACIENTES = "pacientes.dat";

//METODOS DE LA CLASE

void Paciente::cargar() {
    cout << "Ingrese nombre: ";
    cin >> nombre;
    cout << "Ingrese apellido: ";
    cin >> apellido;
    cout << "Ingrese DNI: ";
    cin >> dni;
    cout << "Ingrese obra social: ";
    cin >> obraSocial;
    activo = true;
}

void Paciente::mostrar() const {
    cout << "-------------------------------------" << endl;
    cout << "Nombre: " << nombre << " " << apellido << endl;
    cout << "DNI: " << dni << endl;
    cout << "Obra social: " << obraSocial << endl;
    cout << "Estado: " << (activo ? "Activo" : "Inactivo") << endl;
}

// METODOS DE ARCHIVO

bool Paciente::guardarEnArchivo() const {
    ofstream file(ARCHIVO_PACIENTES, ios::app | ios::binary);
    if (!file) return false;
    file.write(reinterpret_cast<const char*>(this), sizeof(Paciente));
    file.close();
    return true;
}

bool Paciente::leerDeArchivo(int pos) {
    ifstream file(ARCHIVO_PACIENTES, ios::binary);
    if (!file) return false;
    file.seekg(pos * sizeof(Paciente), ios::beg);
    file.read(reinterpret_cast<char*>(this), sizeof(Paciente));
    file.close();
    return file.good();
}

//FUNCIONES DE MENU

void menuPacientes() {
    int opcion;
    do {
        system("cls");
        cout << "=== GESTION DE PACIENTES ===" << endl;
        cout << "1. Alta de Paciente" << endl;
        cout << "2. Listar Pacientes" << endl;
        cout << "3. Buscar por DNI" << endl;
        cout << "4. Baja de Paciente" << endl;
        cout << "0. Volver" << endl;
        cout << "Seleccione una opcion: ";
        cin >> opcion;
        system("cls");

        switch (opcion) {
            case 1: altaPaciente(); break;
            case 2: listarPacientes(); break;
            case 3: buscarPacientePorDNI(); break;
            case 4: bajaPaciente(); break;
            case 0: break;
            default: cout << "Opcion incorrecta." << endl; system("pause");
        }
    } while (opcion != 0);
}

//FUNCIONALIDADES

void altaPaciente() {
    Paciente p;
    p.cargar();
    if (p.guardarEnArchivo())
        cout << "Paciente guardado correctamente." << endl;
    else
        cout << "Error al guardar el paciente." << endl;
    system("pause");
}

void listarPacientes() {
    ifstream file(ARCHIVO_PACIENTES, ios::binary);
    if (!file) {
        cout << "No se puede abrir el archivo." << endl;
        system("pause");
        return;
    }

    Paciente p;
    int i = 0;
    while (file.read(reinterpret_cast<char*>(&p), sizeof(Paciente))) {
        cout << "Paciente #" << ++i << endl;
        p.mostrar();
    }

    if (i == 0)
        cout << "No hay pacientes cargados." << endl;

    file.close();
    system("pause");
}

void buscarPacientePorDNI() {
    int dniBuscado;
    cout << "Ingrese DNI a buscar: ";
    cin >> dniBuscado;

    ifstream file(ARCHIVO_PACIENTES, ios::binary);
    if (!file) {
        cout << "No se puede abrir el archivo." << endl;
        system("pause");
        return;
    }

    Paciente p;
    bool encontrado = false;

    while (file.read(reinterpret_cast<char*>(&p), sizeof(Paciente))) {
        if (p.getDNI() == dniBuscado && p.getActivo()) {
            cout << "Paciente encontrado:" << endl;
            p.mostrar();
            encontrado = true;
            break;
        }
    }

    if (!encontrado)
        cout << "No se encontro un paciente con ese DNI." << endl;

    file.close();
    system("pause");
}

void bajaPaciente() {
    int dniBuscado;
    cout << "Ingrese DNI del paciente a dar de baja: ";
    cin >> dniBuscado;

    fstream file(ARCHIVO_PACIENTES, ios::in | ios::out | ios::binary);
    if (!file) {
        cout << "No se puede abrir el archivo." << endl;
        system("pause");
        return;
    }

    Paciente p;
    bool encontrado = false;
    int pos = 0;

    while (file.read(reinterpret_cast<char*>(&p), sizeof(Paciente))) {
        if (p.getDNI() == dniBuscado && p.getActivo()) {
            p.setActivo(false);
            file.seekp(pos * sizeof(Paciente), ios::beg);
            file.write(reinterpret_cast<char*>(&p), sizeof(Paciente));
            cout << "Paciente dado de baja correctamente." << endl;
            encontrado = true;
            break;
        }
        pos++;
    }

    if (!encontrado)
        cout << "No se encontro el paciente o ya estaba dado de baja." << endl;

    file.close();
    system("pause");
}
