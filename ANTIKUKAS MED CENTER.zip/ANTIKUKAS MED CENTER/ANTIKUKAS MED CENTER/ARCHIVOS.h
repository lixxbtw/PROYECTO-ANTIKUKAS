#ifndef ARCHIVOS_H
#define ARCHIVOS_H

template <typename T>
bool guardarRegistro(const char* nombreArchivo, const T& obj);

template <typename T>
bool leerRegistro(const char* nombreArchivo, T& obj, int pos);

#endif
