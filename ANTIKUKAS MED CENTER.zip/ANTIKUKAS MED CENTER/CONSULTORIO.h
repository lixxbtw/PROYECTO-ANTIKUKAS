
#ifndef CONSULTORIO_H
#define CONSULTORIO_H

class Consultorio {
private:
    int id;
    int numero;
    int piso;
    char especialidad[30];

public:
    void cargar();
    void mostrar() const;
};

void menuConsultorios();

#endif
