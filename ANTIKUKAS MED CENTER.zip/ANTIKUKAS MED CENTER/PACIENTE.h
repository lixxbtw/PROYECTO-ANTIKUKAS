#ifndef PACIENTE_H
#define PACIENTE_H

#include <iostream>
using namespace std;

class Paciente {
private:
    int id;
    char nombre[30];
    char apellido[30];
    int dni;
    char obraSocial[30];
    bool activo;  // true = activo, false = dado de baja

public:
    // --- M�TODOS PRINCIPALES ---
    void cargar();
    void mostrar() const;

    // --- GETTERS ---
    int getDNI() const { return dni; }
    bool getActivo() const { return activo; }
    const char* getNombre() const { return nombre; }
    const char* getApellido() const { return apellido; }

    // --- SETTERS ---
    void setActivo(bool estado) { activo = estado; }

    // --- ARCHIVOS ---
    bool guardarEnArchivo() const;
    bool leerDeArchivo(int pos);
};

// Funciones del men� Pacientes
void menuPacientes();
void altaPaciente();
void listarPacientes();
void buscarPacientePorDNI();
void bajaPaciente();

#endif
