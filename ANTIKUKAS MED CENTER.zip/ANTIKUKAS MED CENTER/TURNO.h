#ifndef TURNO_H
#define TURNO_H

class Turno {
private:
    int id;
    int dniPaciente;
    int idMedico;
    char fecha[11];
    char hora[6];
    bool atendido;

public:
    void cargar();
    void mostrar() const;
};

void menuTurnos();

#endif
