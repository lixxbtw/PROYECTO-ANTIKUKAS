
#ifndef MEDICO_H
#define MEDICO_H

class Medico {
private:
    int id;
    char nombre[30];
    char apellido[30];
    char especialidad[30];
    bool activo;

public:
    void cargar();
    void mostrar() const;
    bool getEstado() const;
};

void menuMedicos();

#endif
