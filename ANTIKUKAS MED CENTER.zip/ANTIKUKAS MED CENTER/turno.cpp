
#include <iostream>
#include "Turno.h"
using namespace std;

void Turno::cargar() {
    cout << "Ingrese DNI del paciente: ";
    cin >> dniPaciente;
    cout << "Ingrese ID del medico: ";
    cin >> idMedico;
    cout << "Ingrese fecha (dd/mm/aaaa): ";
    cin >> fecha;
    cout << "Ingrese hora (HH:MM): ";
    cin >> hora;
    atendido = false;
}

void Turno::mostrar() const {
    cout << "Paciente DNI: " << dniPaciente << " | Medico ID: " << idMedico
         << " | Fecha: " << fecha << " | Hora: " << hora << endl;
}

void menuTurnos() {
    cout << "=== MENU TURNOS ===" << endl;
    cout << "1. Asignar Turno" << endl;
    cout << "2. Listar Turnos" << endl;
    cout << "3. Consultar por Fecha o Medico" << endl;
    cout << "4. Volver" << endl;
    system("pause");
}
