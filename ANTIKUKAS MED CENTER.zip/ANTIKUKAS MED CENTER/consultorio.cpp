
#include <iostream>
#include "Consultorio.h"
using namespace std;

void Consultorio::cargar() {
    cout << "Ingrese numero del consultorio: ";
    cin >> numero;
    cout << "Ingrese piso: ";
    cin >> piso;
    cout << "Ingrese especialidad: ";
    cin >> especialidad;
}

void Consultorio::mostrar() const {
    cout << "Consultorio N�" << numero << " | Piso: " << piso
         << " | Especialidad: " << especialidad << endl;
}

void menuConsultorios() {
    cout << "=== MENU CONSULTORIOS ===" << endl;
    cout << "1. Alta de Consultorio" << endl;
    cout << "2. Listar Consultorios" << endl;
    cout << "3. Buscar por Especialidad" << endl;
    cout << "4. Volver" << endl;
    system("pause");
}
