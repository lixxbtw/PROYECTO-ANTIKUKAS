#include <iostream>
#include <fstream>
#include <cstring>
#include "Consultorio.h"
using namespace std;

const char* ARCHIVO_CONSULTORIOS = "consultorios.dat";

//Metodos de la clase

void Consultorio::cargar() {
    cout << "Ingrese numero del consultorio: ";
    cin >> numero;
    cout << "Ingrese piso: ";
    cin >> piso;
    cout << "Ingrese especialidad: ";
    cin >> especialidad;
    activo = true;
}

void Consultorio::mostrar() const {
    cout << "---------------------------------" << endl;
    cout << "Numero: " << numero << " | Piso: " << piso << endl;
    cout << "Especialidad: " << especialidad << endl;
    cout << "Estado: " << (activo ? "Activo" : "Inactivo") << endl;
}

//Manejo de archivos

bool Consultorio::guardarEnArchivo() const {
    ofstream file(ARCHIVO_CONSULTORIOS, ios::app | ios::binary);
    if (!file) return false;
    file.write((const char*)this, sizeof(Consultorio));
    file.close();
    return true;
}

bool Consultorio::leerDeArchivo(int pos) {
    ifstream file(ARCHIVO_CONSULTORIOS, ios::binary);
    if (!file) return false;
    file.seekg(pos * sizeof(Consultorio), ios::beg);
    file.read((char*)this, sizeof(Consultorio));
    file.close();
    return file.good();
}

//Funciones de menu

void menuConsultorios() {
    int opcion;
    do {
        system("cls");
        cout << "=== GESTION DE CONSULTORIOS ===" << endl;
        cout << "1. Alta de Consultorio" << endl;
        cout << "2. Listar Consultorios" << endl;
        cout << "3. Buscar por Especialidad" << endl;
        cout << "4. Buscar por Piso" << endl;
        cout << "5. Baja de Consultorio" << endl;
        cout << "0. Volver" << endl;
        cout << "Seleccione una opcion: ";
        cin >> opcion;
        system("cls");

        switch (opcion) {
            case 1: altaConsultorio(); break;
            case 2: listarConsultorios(); break;
            case 3: buscarConsultorioPorEspecialidad(); break;
            case 4: buscarConsultorioPorPiso(); break;
            case 5: bajaConsultorio(); break;
            case 0: break;
            default: cout << "Opcion incorrecta." << endl; system("pause");
        }
    } while (opcion != 0);
}

//Funcionalidades

void altaConsultorio() {
    Consultorio c;
    c.cargar();
    if (c.guardarEnArchivo())
        cout << "Consultorio guardado correctamente." << endl;
    else
        cout << "Error al guardar consultorio." << endl;
    system("pause");
}

void listarConsultorios() {
    ifstream file(ARCHIVO_CONSULTORIOS, ios::binary);
    if (!file) {
        cout << "No se puede abrir el archivo." << endl;
        system("pause");
        return;
    }

    Consultorio c;
    int contador = 0;

    while (file.read((char*)&c, sizeof(Consultorio))) {
        cout << "Consultorio #" << ++contador << endl;
        c.mostrar();
    }

    if (contador == 0)
        cout << "No hay consultorios cargados." << endl;

    file.close();
    system("pause");
}

void buscarConsultorioPorEspecialidad() {
    char espBuscada[30];
    cout << "Ingrese especialidad a buscar: ";
    cin >> espBuscada;

    ifstream file(ARCHIVO_CONSULTORIOS, ios::binary);
    if (!file) {
        cout << "No se puede abrir el archivo." << endl;
        system("pause");
        return;
    }

    Consultorio c;
    bool encontrado = false;

    while (file.read((char*)&c, sizeof(Consultorio))) {
        if (strcmp(c.getEspecialidad(), espBuscada) == 0 && c.getActivo()) {
            c.mostrar();
            encontrado = true;
        }
    }

    if (!encontrado)
        cout << "No se encontro ningun consultorio con esa especialidad." << endl;

    file.close();
    system("pause");
}

void buscarConsultorioPorPiso() {
    int pisoBuscado;
    cout << "Ingrese piso a buscar: ";
    cin >> pisoBuscado;

    ifstream file(ARCHIVO_CONSULTORIOS, ios::binary);
    if (!file) {
        cout << "No se puede abrir el archivo." << endl;
        system("pause");
        return;
    }

    Consultorio c;
    bool encontrado = false;

    while (file.read((char*)&c, sizeof(Consultorio))) {
        if (c.getPiso() == pisoBuscado && c.getActivo()) {
            c.mostrar();
            encontrado = true;
        }
    }

    if (!encontrado)
        cout << "No se encontro ningun consultorio en ese piso." << endl;

    file.close();
    system("pause");
}

void bajaConsultorio() {
    int numeroBuscado;
    cout << "Ingrese numero del consultorio a dar de baja: ";
    cin >> numeroBuscado;

    fstream file(ARCHIVO_CONSULTORIOS, ios::in | ios::out | ios::binary);
    if (!file) {
        cout << "No se puede abrir el archivo." << endl;
        system("pause");
        return;
    }

    Consultorio c;
    bool encontrado = false;
    int pos = 0;

    while (file.read((char*)&c, sizeof(Consultorio))) {
        if (c.getNumero() == numeroBuscado && c.getActivo()) {
            c.setActivo(false);
            file.seekp(pos * sizeof(Consultorio), ios::beg);
            file.write((char*)&c, sizeof(Consultorio));
            cout << "Consultorio dado de baja correctamente." << endl;
            encontrado = true;
            break;
        }
        pos++;
    }

    if (!encontrado)
        cout << "No se encontro el consultorio o ya estaba inactivo." << endl;

    file.close();
    system("pause");
}
