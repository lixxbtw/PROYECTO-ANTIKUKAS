// FuncionesGenerales.h
#ifndef FUNCIONESGENERALES_H
#define FUNCIONESGENERALES_H

void limpiarPantalla();
void pausa();

#endif
