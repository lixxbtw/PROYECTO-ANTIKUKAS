#include <iostream>
#include "Medico.h"
using namespace std;

void Medico::cargar() {
    cout << "Ingrese nombre: ";
    cin >> nombre;
    cout << "Ingrese apellido: ";
    cin >> apellido;
    cout << "Ingrese especialidad: ";
    cin >> especialidad;
    activo = true;
}

void Medico::mostrar() const {
    cout << "Dr/a. " << nombre << " " << apellido << " - " << especialidad << endl;
}

void menuMedicos() {
    cout << "=== MENU MEDICOS ===" << endl;
    cout << "1. Alta de Medico" << endl;
    cout << "2. Listar Medicos" << endl;
    cout << "3. Buscar por Especialidad" << endl;
    cout << "4. Volver" << endl;
    system("pause");
}
