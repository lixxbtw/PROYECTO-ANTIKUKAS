#ifndef CONSULTORIO_H_INCLUDED
#define CONSULTORIO_H_INCLUDED

class Consultorio {
private:
    int id;
    char nombre[30];
    char especialidad[30];
public:
    Consultorio();
    void cargar();
    void mostrar() const;
    int getID() const {
    return id; }
};

#endif // CONSULTORIO_H_INCLUDED

