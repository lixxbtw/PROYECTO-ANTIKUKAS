#ifndef CONSULTORIO_H_INCLUDED
#define CONSULTORIO_H_INCLUDED

class Consultorio {
private:
    int id;
    char nombre[30];
    char especialidad[30];
    bool activo;

public:
    Consultorio();
    void cargar();
    void mostrar() const;

    int getID() const { return id; }

    bool getActivo() const { return activo; }
    void setActivo(bool estado) { activo = estado; }
    void desactivar() { activo = false; }
};

#endif // CONSULTORIO_H_INCLUDED
