#ifndef PERSONA_H_INCLUDED
#define PERSONA_H_INCLUDED

class Persona {
protected:
    char nombre[30];
    char apellido[30];
    int dni;
public:
    Persona();
    void cargar();
    void mostrar() const;
    int getDNI() const { return dni; }
};

#endif // PERSONA_H_INCLUDED
