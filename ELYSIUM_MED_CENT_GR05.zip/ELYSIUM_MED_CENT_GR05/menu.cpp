#include <iostream>
#include <cstdlib>
#include "rlutil.h"
#include "ArchivoPaciente.h"
#include "ArchivoMedico.h"
#include "ArchivoConsultorio.h"
#include "ArchivoTurno.h"
#include "Funciones.h"
#include "Paciente.h"
#include "Medico.h"
#include "Consultorio.h"
#include "Turno.h"

using namespace std;
using namespace rlutil;

// ==== PROTOTIPOS ====
void menuPacientes(ArchivoPaciente& archPac);
void menuMedicos(ArchivoMedico& archMed);
void menuConsultorios(ArchivoConsultorio& archCons);
void menuTurnos(ArchivoTurno& archTurn);

// ==== FUNCION AUXILIAR ====
void mostrarMensaje(const string& texto, bool exito = true) {
    system("cls");
    rlutil::setBackgroundColor(rlutil::BLUE);
    int x = rlutil::tcols() / 2 - (texto.size() / 2);
    int y = rlutil::trows() / 2;
    rlutil::locate(x, y);
    rlutil::setColor(exito ? rlutil::GREEN : rlutil::RED);
    cout << texto;
    rlutil::setColor(rlutil::WHITE);
    rlutil::locate(rlutil::tcols() / 2 - 15, y + 2);
    cout << "Presione ENTER para continuar...";
    cin.ignore();
    cin.get();
}

// ==== MENU PRINCIPAL ====
int main() {
    ArchivoMedico archMed;
    ArchivoPaciente archPac;
    ArchivoConsultorio archCons;
    ArchivoTurno archTurn;
    int opcion;

    while (true) {
        rlutil::setBackgroundColor(rlutil::BLUE);
        rlutil::setColor(rlutil::WHITE);
        system("cls");

        int x = rlutil::tcols() / 2 - 20;
        int y = rlutil::trows() / 2 - 6;
        rlutil::locate(x, y);
        cout << "============================================" << endl;
        rlutil::locate(x, y + 1);
        cout << "           SISTEMA DE GESTION CLINICA       " << endl;
        rlutil::locate(x, y + 2);
        cout << "============================================" << endl;

        rlutil::locate(x, y + 4); cout << "1. Gestion de Pacientes" << endl;
        rlutil::locate(x, y + 5); cout << "2. Gestion de Medicos" << endl;
        rlutil::locate(x, y + 6); cout << "3. Gestion de Consultorios" << endl;
        rlutil::locate(x, y + 7); cout << "4. Gestion de Turnos" << endl;
        rlutil::locate(x, y + 8); cout << "0. Salir" << endl;

        rlutil::locate(x, y + 10);
        cout << "Seleccione una opcion: ";
        cin >> opcion;

        switch (opcion) {
            case 1: menuPacientes(archPac); break;
            case 2: menuMedicos(archMed); break;
            case 3: menuConsultorios(archCons); break;
            case 4: menuTurnos(archTurn); break;
            case 0:
                mostrarMensaje("Saliendo del sistema...", true);
                return 0;
            default:
                mostrarMensaje("Opcion invalida.", false);
                break;
        }
    }
}

// ==== MENU PACIENTES ====
void menuPacientes(ArchivoPaciente& archPac) {
    int op;
    while (true) {
        rlutil::setBackgroundColor(rlutil::BLUE);
        rlutil::setColor(rlutil::WHITE);
        system("cls");

        int x = rlutil::tcols() / 2 - 20;
        int y = rlutil::trows() / 2 - 6;
        rlutil::locate(x, y); cout << "======================================" << endl;
        rlutil::locate(x, y + 1); cout << "        GESTION DE PACIENTES" << endl;
        rlutil::locate(x, y + 2); cout << "======================================" << endl;
        rlutil::locate(x, y + 4); cout << "1. Alta de Paciente" << endl;
        rlutil::locate(x, y + 5); cout << "2. Listar Pacientes" << endl;
        rlutil::locate(x, y + 6); cout << "3. Buscar Paciente por DNI" << endl;
        rlutil::locate(x, y + 7); cout << "4. Eliminar Paciente" << endl;
        rlutil::locate(x, y + 8); cout << "0. Volver" << endl;
        rlutil::locate(x, y + 10); cout << "Seleccione una opcion: ";
        cin >> op;

        switch (op) {
            case 1: {
                Paciente p;
                p.cargar();
                if (archPac.guardar(p))
                    mostrarMensaje("Paciente guardado correctamente.", true);
                else
                    mostrarMensaje("Error al guardar paciente.", false);
                break;
            }
            case 2:
                archPac.listarTodos();
                break;
            case 3: {
                int dni;
                cout << "Ingrese DNI: ";
                cin >> dni;
                int pos = buscarPorClave<Paciente>("pacientes.dat", [](const Paciente& p){ return p.getDNI(); }, dni);
                if (pos >= 0)
                    mostrarMensaje("Paciente encontrado en posicion " + to_string(pos + 1), true);
                else
                    mostrarMensaje("No se encontro un paciente con ese DNI.", false);
                break;
            }
            case 4: {
                int dni;
                cout << "Ingrese DNI a eliminar: ";
                cin >> dni;
                int pos = buscarPorClave<Paciente>("pacientes.dat", [](const Paciente& p){ return p.getDNI(); }, dni);
                if (pos >= 0 && archPac.borrar(pos))
                    mostrarMensaje("Paciente eliminado correctamente.", true);
                else
                    mostrarMensaje("Error al eliminar paciente o no existe.", false);
                break;
            }
            case 0: return;
            default: mostrarMensaje("Opcion invalida.", false); break;
        }
    }
}

// ==== MENU MEDICOS ====
void menuMedicos(ArchivoMedico& archMed) {
    int op;
    while (true) {
        rlutil::setBackgroundColor(rlutil::BLUE);
        rlutil::setColor(rlutil::WHITE);
        system("cls");

        int x = rlutil::tcols() / 2 - 20;
        int y = rlutil::trows() / 2 - 6;
        rlutil::locate(x, y); cout << "======================================" << endl;
        rlutil::locate(x, y + 1); cout << "        GESTION DE MEDICOS" << endl;
        rlutil::locate(x, y + 2); cout << "======================================" << endl;
        rlutil::locate(x, y + 4); cout << "1. Alta de Medico" << endl;
        rlutil::locate(x, y + 5); cout << "2. Listar Medicos" << endl;
        rlutil::locate(x, y + 6); cout << "3. Buscar Medico por Legajo" << endl;
        rlutil::locate(x, y + 7); cout << "4. Eliminar Medico" << endl;
        rlutil::locate(x, y + 8); cout << "5. Desactivar Medico" << endl;
        rlutil::locate(x, y + 9); cout << "0. Volver" << endl;
        rlutil::locate(x, y + 11); cout << "Seleccione una opcion: ";
        cin >> op;

        switch (op) {
            case 1: {
                Medico m;
                m.setLegajo(archMed.cantidad() + 1);
                m.cargar();
                if (archMed.guardar(m))
                    mostrarMensaje("Medico guardado correctamente.", true);
                else
                    mostrarMensaje("Error al guardar medico.", false);
                break;
            }
            case 2:
                archMed.listarTodos();
                break;
            case 3: {
                int legajo;
                cout << "Ingrese legajo: ";
                cin >> legajo;
                int pos = buscarPorClave<Medico>("medicos.dat", [](const Medico& m){ return m.getLegajo(); }, legajo);
                if (pos >= 0)
                    mostrarMensaje("Medico encontrado en posicion " + to_string(pos + 1), true);
                else
                    mostrarMensaje("No se encontro un medico con ese legajo.", false);
                break;
            }
            case 4: {
                int legajo;
                cout << "Ingrese legajo a eliminar: ";
                cin >> legajo;
                int pos = buscarPorClave<Medico>("medicos.dat", [](const Medico& m){ return m.getLegajo(); }, legajo);
                if (pos >= 0 && archMed.borrar(pos))
                    mostrarMensaje("Medico eliminado correctamente.", true);
                else
                    mostrarMensaje("Error al eliminar medico o no existe.", false);
                break;
            }
            case 5: {
                int legajo;
                cout << "Ingrese legajo del medico a desactivar: ";
                cin >> legajo;
                int pos = buscarPorClave<Medico>("medicos.dat", [](const Medico& m){ return m.getLegajo(); }, legajo);
                if (pos >= 0) {
                    Medico m;
                    Archivo<Medico> archivo("medicos.dat");
                    if (archivo.leer(m, pos)) {
                        m.desactivar();
                        FILE* p = fopen("medicos.dat", "rb+");
                        fseek(p, pos * sizeof(Medico), SEEK_SET);
                        fwrite(&m, sizeof(Medico), 1, p);
                        fclose(p);
                        mostrarMensaje("Medico desactivado correctamente.", true);
                    }
                } else
                    mostrarMensaje("No se encontro un medico con ese legajo.", false);
                break;
            }
            case 0: return;
            default: mostrarMensaje("Opcion invalida.", false); break;
        }
    }
}

// ==== MENU CONSULTORIOS ====
void menuConsultorios(ArchivoConsultorio& archCons) {
    int op;
    while (true) {
        rlutil::setBackgroundColor(rlutil::BLUE);
        rlutil::setColor(rlutil::WHITE);
        system("cls");

        int x = rlutil::tcols() / 2 - 20;
        int y = rlutil::trows() / 2 - 6;
        rlutil::locate(x, y); cout << "======================================" << endl;
        rlutil::locate(x, y + 1); cout << "       GESTION DE CONSULTORIOS" << endl;
        rlutil::locate(x, y + 2); cout << "======================================" << endl;
        rlutil::locate(x, y + 4); cout << "1. Alta de Consultorio" << endl;
        rlutil::locate(x, y + 5); cout << "2. Listar Consultorios" << endl;
        rlutil::locate(x, y + 6); cout << "3. Buscar Consultorio por ID" << endl;
        rlutil::locate(x, y + 7); cout << "4. Eliminar Consultorio" << endl;
        rlutil::locate(x, y + 8); cout << "5. Desactivar Consultorio" << endl;
        rlutil::locate(x, y + 9); cout << "0. Volver" << endl;
        rlutil::locate(x, y + 11); cout << "Seleccione una opcion: ";
        cin >> op;

        switch (op) {
            case 1: {
                Consultorio c;
                c.cargar();
                if (archCons.guardar(c))
                    mostrarMensaje("Consultorio guardado correctamente.", true);
                else
                    mostrarMensaje("Error al guardar consultorio.", false);
                break;
            }
            case 2:
                archCons.listarTodos();
                break;
            case 3: {
                int id;
                cout << "Ingrese ID: ";
                cin >> id;
                int pos = buscarPorClave<Consultorio>("consultorios.dat", [](const Consultorio& c){ return c.getID(); }, id);
                if (pos >= 0)
                    mostrarMensaje("Consultorio encontrado en posicion " + to_string(pos + 1), true);
                else
                    mostrarMensaje("No se encontro un consultorio con ese ID.", false);
                break;
            }
            case 4: {
                int id;
                cout << "Ingrese ID a eliminar: ";
                cin >> id;
                int pos = buscarPorClave<Consultorio>("consultorios.dat", [](const Consultorio& c){ return c.getID(); }, id);
                if (pos >= 0 && archCons.borrar(pos))
                    mostrarMensaje("Consultorio eliminado correctamente.", true);
                else
                    mostrarMensaje("Error al eliminar consultorio o no existe.", false);
                break;
            }
            case 5: {
                int id;
                cout << "Ingrese ID del consultorio a desactivar: ";
                cin >> id;
                int pos = buscarPorClave<Consultorio>("consultorios.dat", [](const Consultorio& c){ return c.getID(); }, id);
                if (pos >= 0) {
                    Consultorio c;
                    Archivo<Consultorio> archivo("consultorios.dat");
                    if (archivo.leer(c, pos)) {
                        c.desactivar();
                        FILE* p = fopen("consultorios.dat", "rb+");
                        fseek(p, pos * sizeof(Consultorio), SEEK_SET);
                        fwrite(&c, sizeof(Consultorio), 1, p);
                        fclose(p);
                        mostrarMensaje("Consultorio desactivado correctamente.", true);
                    }
                } else
                    mostrarMensaje("No se encontro un consultorio con ese ID.", false);
                break;
            }
            case 0: return;
            default: mostrarMensaje("Opcion invalida.", false); break;
        }
    }
}

// ==== MENU TURNOS ====
void menuTurnos(ArchivoTurno& archTurn) {
    int op;
    while (true) {
        rlutil::setBackgroundColor(rlutil::BLUE);
        rlutil::setColor(rlutil::WHITE);
        system("cls");

        int x = rlutil::tcols() / 2 - 20;
        int y = rlutil::trows() / 2 - 6;
        rlutil::locate(x, y); cout << "======================================" << endl;
        rlutil::locate(x, y + 1); cout << "          GESTION DE TURNOS" << endl;
        rlutil::locate(x, y + 2); cout << "======================================" << endl;
        rlutil::locate(x, y + 4); cout << "1. Alta de Turno" << endl;
        rlutil::locate(x, y + 5); cout << "2. Listar Turnos" << endl;
        rlutil::locate(x, y + 6); cout << "3. Buscar Turno por ID" << endl;
        rlutil::locate(x, y + 7); cout << "4. Eliminar Turno" << endl;
        rlutil::locate(x, y + 8); cout << "0. Volver" << endl;
        rlutil::locate(x, y + 10); cout << "Seleccione una opcion: ";
        cin >> op;

        switch (op) {
            case 1: {
                Turno t;
                t.cargar();
                t.setID(archTurn.cantidad() + 1);
                if (archTurn.guardar(t))
                    mostrarMensaje("Turno guardado correctamente.", true);
                else
                    mostrarMensaje("Error al guardar turno.", false);
                break;
            }
            case 2:
                archTurn.listarTodos();
                break;
            case 3: {
                int id;
                cout << "Ingrese ID: ";
                cin >> id;
                int pos = buscarPorClave<Turno>("turnos.dat", [](const Turno& t){ return t.getID(); }, id);
                if (pos >= 0)
                    mostrarMensaje("Turno encontrado en posicion " + to_string(pos + 1), true);
                else
                    mostrarMensaje("No se encontro un turno con ese ID.", false);
                break;
            }
            case 4: {
                int id;
                cout << "Ingrese ID a eliminar: ";
                cin >> id;
                int pos = buscarPorClave<Turno>("turnos.dat", [](const Turno& t){ return t.getID(); }, id);
                if (pos >= 0 && archTurn.borrar(pos))
                    mostrarMensaje("Turno eliminado correctamente.", true);
                else
                    mostrarMensaje("Error al eliminar turno o no existe.", false);
                break;
            }
            case 0: return;
            default: mostrarMensaje("Opcion invalida.", false); break;
        }
    }
}
