#include <iostream>
#include <cstdlib>
#include "rlutil.h"
#include "ArchivoPaciente.h"
#include "ArchivoMedico.h"
#include "ArchivoConsultorio.h"
#include "ArchivoTurno.h"
#include "Funciones.h"
#include "Paciente.h"
#include "Medico.h"
#include "Consultorio.h"
#include "Turno.h"

using namespace std;
using namespace rlutil;

// ==== PROTOTIPOS DE MENUS ====
void menuPacientes(ArchivoPaciente& archPac);
void menuMedicos(ArchivoMedico& archMed);
void menuConsultorios(ArchivoConsultorio& archCons);
void menuTurnos(ArchivoTurno& archTurn);

// ==== MENU PRINCIPAL ====
int main() {
    ArchivoMedico archMed;
    ArchivoPaciente archPac;
    ArchivoConsultorio archCons;
    ArchivoTurno archTurn;

    int opcion;

    while (true) {
        rlutil::setBackgroundColor(rlutil::BLUE);
        rlutil::setColor(rlutil::WHITE);
        system("cls");


        int x = rlutil::tcols() / 2 - 20;
        int y = rlutil::trows() / 2 - 6;
        rlutil::locate(x, y);
        cout << "============================================" << endl;
        rlutil::locate(x, y + 1);
        cout << "           SISTEMA DE GESTION CLINICA       " << endl;
        rlutil::locate(x, y + 2);
        cout << "============================================" << endl;

        rlutil::locate(x, y + 4);
        cout << "1. Gestion de Pacientes" << endl;
        rlutil::locate(x, y + 5);
        cout << "2. Gestion de Medicos" << endl;
        rlutil::locate(x, y + 6);
        cout << "3. Gestion de Consultorios" << endl;
        rlutil::locate(x, y + 7);
        cout << "4. Gestion de Turnos" << endl;
        rlutil::locate(x, y + 8);
        cout << "0. Salir" << endl;

        rlutil::locate(x, y + 10);
        cout << "Seleccione una opcion: ";
        cin >> opcion;

        switch (opcion) {
            case 1: menuPacientes(archPac); break;
            case 2: menuMedicos(archMed); break;
            case 3: menuConsultorios(archCons); break;
            case 4: menuTurnos(archTurn); break;
            case 0:
                cout << "Saliendo del sistema..." << endl;
                return 0;
            default:
                cout << "Opcion invalida." << endl;
                break;
        }

        cout << "Presione ENTER para continuar...";
        cin.ignore();
        cin.get();
    }
}

// ==== MENU PACIENTES ====
void menuPacientes(ArchivoPaciente& archPac) {
    int op;
    while (true) {
        system("cls");
        cout << "======================================" << endl;
        cout << "        GESTION DE PACIENTES" << endl;
        cout << "======================================" << endl;
        cout << "1. Alta de Paciente" << endl;
        cout << "2. Listar Pacientes" << endl;
        cout << "3. Buscar Paciente por DNI" << endl;
        cout << "4. Eliminar Paciente" << endl;
        cout << "0. Volver" << endl;
        cout << "--------------------------------------" << endl;
        cout << "Seleccione una opcion: ";
        cin >> op;

        switch (op) {
            case 1: {
                Paciente p;
                p.cargar();
                if (archPac.guardar(p)) cout << "Paciente guardado correctamente." << endl;
                else cout << "Error al guardar paciente." << endl;
                break;
            }
            case 2:
                archPac.listarTodos();
                break;
            case 3: {
                int dni;
                cout << "Ingrese DNI: ";
                cin >> dni;
                int pos = buscarPorClave<Paciente>("pacientes.dat", [](const Paciente& p){ return p.getDNI(); }, dni);
                if (pos >= 0) cout << "Paciente encontrado en posicion " << pos << endl;
                else cout << "No se encontro un paciente con ese DNI." << endl;
                break;
            }
            case 4: {
                int dni;
                cout << "Ingrese DNI a eliminar: ";
                cin >> dni;
                int pos = buscarPorClave<Paciente>("pacientes.dat", [](const Paciente& p){ return p.getDNI(); }, dni);
                if (pos >= 0 && archPac.borrar(pos)) cout << "Paciente eliminado correctamente." << endl;
                else cout << "Error al eliminar paciente o no existe." << endl;
                break;
            }
            case 0: return;
            default: cout << "Opcion invalida." << endl; break;
        }

        cout << "Presione ENTER para continuar...";
        cin.ignore();
        cin.get();
    }
}

// ==== MENU MEDICOS ====
void menuMedicos(ArchivoMedico& archMed) {
    int op;
    while (true) {
        system("cls");
        cout << "======================================" << endl;
        cout << "        GESTION DE MEDICOS" << endl;
        cout << "======================================" << endl;
        cout << "1. Alta de Medico" << endl;
        cout << "2. Listar Medicos" << endl;
        cout << "3. Buscar Medico por Legajo" << endl;
        cout << "4. Eliminar Medico" << endl;
        cout << "0. Volver" << endl;
        cout << "--------------------------------------" << endl;
        cout << "Seleccione una opcion: ";
        cin >> op;

        switch (op) {
            case 1: {
                Medico m;
                m.cargar();
                if (archMed.guardar(m)) cout << "Medico guardado correctamente." << endl;
                else cout << "Error al guardar medico." << endl;
                break;
            }
            case 2:
                archMed.listarTodos();
                break;
            case 3: {
                int legajo;
                cout << "Ingrese legajo: ";
                cin >> legajo;
                int pos = buscarPorClave<Medico>("medicos.dat", [](const Medico& m){ return m.getLegajo(); }, legajo);
                if (pos >= 0) cout << "Medico encontrado en posicion " << pos << endl;
                else cout << "No se encontro un medico con ese legajo." << endl;
                break;
            }
            case 4: {
                int legajo;
                cout << "Ingrese legajo a eliminar: ";
                cin >> legajo;
                int pos = buscarPorClave<Medico>("medicos.dat", [](const Medico& m){ return m.getLegajo(); }, legajo);
                if (pos >= 0 && archMed.borrar(pos)) cout << "Medico eliminado correctamente." << endl;
                else cout << "Error al eliminar medico o no existe." << endl;
                break;
            }
            case 0: return;
            default: cout << "Opcion invalida." << endl; break;
        }

        cout << "Presione ENTER para continuar...";
        cin.ignore();
        cin.get();
    }
}

// ==== MENU CONSULTORIOS ====
void menuConsultorios(ArchivoConsultorio& archCons) {
    int op;
    while (true) {
        system("cls");
        cout << "======================================" << endl;
        cout << "       GESTION DE CONSULTORIOS" << endl;
        cout << "======================================" << endl;
        cout << "1. Alta de Consultorio" << endl;
        cout << "2. Listar Consultorios" << endl;
        cout << "3. Buscar Consultorio por ID" << endl;
        cout << "4. Eliminar Consultorio" << endl;
        cout << "0. Volver" << endl;
        cout << "--------------------------------------" << endl;
        cout << "Seleccione una opcion: ";
        cin >> op;

        switch (op) {
            case 1: {
                Consultorio c;
                c.cargar();
                if (archCons.guardar(c)) cout << "Consultorio guardado correctamente." << endl;
                else cout << "Error al guardar consultorio." << endl;
                break;
            }
            case 2:
                archCons.listarTodos();
                break;
            case 3: {
                int id;
                cout << "Ingrese ID: ";
                cin >> id;
                int pos = buscarPorClave<Consultorio>("consultorios.dat", [](const Consultorio& c){ return c.getID(); }, id);
                if (pos >= 0) cout << "Consultorio encontrado en posicion " << pos << endl;
                else cout << "No se encontro un consultorio con ese ID." << endl;
                break;
            }
            case 4: {
                int id;
                cout << "Ingrese ID a eliminar: ";
                cin >> id;
                int pos = buscarPorClave<Consultorio>("consultorios.dat", [](const Consultorio& c){ return c.getID(); }, id);
                if (pos >= 0 && archCons.borrar(pos)) cout << "Consultorio eliminado correctamente." << endl;
                else cout << "Error al eliminar consultorio o no existe." << endl;
                break;
            }
            case 0: return;
            default: cout << "Opcion invalida." << endl; break;
        }

        cout << "Presione ENTER para continuar...";
        cin.ignore();
        cin.get();
    }
}

// ==== MENU TURNOS ====
void menuTurnos(ArchivoTurno& archTurn) {
    int op;
    while (true) {
        system("cls");
        cout << "======================================" << endl;
        cout << "          GESTION DE TURNOS" << endl;
        cout << "======================================" << endl;
        cout << "1. Alta de Turno" << endl;
        cout << "2. Listar Turnos" << endl;
        cout << "3. Buscar Turno por ID" << endl;
        cout << "4. Eliminar Turno" << endl;
        cout << "0. Volver" << endl;
        cout << "--------------------------------------" << endl;
        cout << "Seleccione una opcion: ";
        cin >> op;

        switch (op) {
            case 1: {
                Turno t;
                t.cargar();
                t.setID(archTurn.cantidad() + 1);
                if (archTurn.guardar(t)) cout << "Turno guardado correctamente." << endl;
                else cout << "Error al guardar turno." << endl;
                break;
            }
            case 2:
                archTurn.listarTodos();
                break;
            case 3: {
                int id;
                cout << "Ingrese ID: ";
                cin >> id;
                int pos = buscarPorClave<Turno>("turnos.dat", [](const Turno& t){ return t.getID(); }, id);
                if (pos >= 0) cout << "Turno encontrado en posicion " << pos << endl;
                else cout << "No se encontro un turno con ese ID." << endl;
                break;
            }
            case 4: {
                int id;
                cout << "Ingrese ID a eliminar: ";
                cin >> id;
                int pos = buscarPorClave<Turno>("turnos.dat", [](const Turno& t){ return t.getID(); }, id);
                if (pos >= 0 && archTurn.borrar(pos)) cout << "Turno eliminado correctamente." << endl;
                else cout << "Error al eliminar turno o no existe." << endl;
                break;
            }
            case 0: return;
            default: cout << "Opcion invalida." << endl; break;
        }

        cout << "Presione ENTER para continuar...";
        cin.ignore();
        cin.get();
    }
}
