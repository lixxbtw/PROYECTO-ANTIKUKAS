#include "Persona.h"
#include <iostream>
#include <cstring>
#include <limits>
#include "rlutil.h"
using namespace std;
using namespace rlutil;

Persona::Persona() {
    nombre[0] = '\0';
    apellido[0] = '\0';
    dni = 0;
}

void Persona::cargar() {
    system("cls");
    setBackgroundColor(BLUE);
    setColor(WHITE);

    int x = rlutil::tcols() / 2 - 20;
    int y = rlutil::trows() / 2 - 3;

    rlutil::locate(x, y);
    cout << "======================================" << endl;
    rlutil::locate(x, y + 1);
    cout << "           CARGA DE PERSONA" << endl;
    rlutil::locate(x, y + 2);
    cout << "======================================" << endl;
    rlutil::locate(x, y + 4);
    cout << "Nombre: ";
    cin >> nombre;
    rlutil::locate(x, y + 5);
    cout << "Apellido: ";
    cin >> apellido;
    rlutil::locate(x, y + 6);
    cout << "DNI (sin puntos): ";
    cin >> dni;
    cin.ignore(numeric_limits<streamsize>::max(), '\n');
}

void Persona::mostrar() const {
    cout << "Nombre: " << nombre << " " << apellido
         << " | DNI: " << dni;
}
