#include "Persona.h"
#include <iostream>
#include <cstring>
#include <limits>
#include "rlutil.h"
using namespace std;

Persona::Persona() {
    nombre[0] = '\0';
    apellido[0] = '\0';
    //dni = 0;
}

void Persona::cargar() {
    cout << "Nombre: ";
    cin >> nombre;
    cout << "Apellido: ";
    cin >> apellido;
    //cout << "DNI (Sin puntos) : ";
    //cin >> dni;
    cin.ignore(numeric_limits<streamsize>::max(), '\n');
}

void Persona::mostrar() const {
    cout << "Nombre: " << nombre << " " << apellido
         << " | DNI: " << dni;
}
