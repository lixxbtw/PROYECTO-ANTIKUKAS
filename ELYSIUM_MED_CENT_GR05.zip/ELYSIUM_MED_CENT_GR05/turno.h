#ifndef TURNO_H_INCLUDED
#define TURNO_H_INCLUDED

#include "Fecha.h"

class Turno {
private:
    int idTurno;
    int dniPaciente;
    char especialidad[30];
    Fecha fecha;

public:
    Turno();
    void cargar();
    void mostrar() const;

    void setID(int id) { idTurno = id; }
    int getID() const { return idTurno; }
    int getDniPaciente() const { return dniPaciente; }
    const char* getEspecialidad() const { return especialidad; }
    Fecha getFecha() const { return fecha; }
};

#endif // TURNO_H_INCLUDED
