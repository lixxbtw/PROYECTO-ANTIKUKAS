#ifndef TURNO_H_INCLUDED
#define TURNO_H_INCLUDED

#include "Fecha.h"

class Turno {
private:
    int idTurno;
    int legajoMedico;
    int dniPaciente;
    Fecha fecha;
public:
    Turno();
    void cargar();
    void mostrar() const;
    void setID(int id) {
        idTurno = id;
    }
    int getID() const {
        return idTurno;
    }
    int getLegajoMedico() const {
        return legajoMedico;
    }
    int getDniPaciente() const {
        return dniPaciente;
    }
    Fecha getFecha() const {
        return fecha;
    }
};

#endif // TURNO_H_INCLUDED
