#ifndef ARCHIVOMEDICO_H_INCLUDED
#define ARCHIVOMEDICO_H_INCLUDED

#include "Archivo.h"
#include "Medico.h"

class ArchivoMedico {
private:
    Archivo<Medico> arch;
public:
    ArchivoMedico() : arch("medicos.dat") {}

    bool guardar(const Medico& m) {
        return arch.guardar(m);
    }

    void listarTodos() {
        arch.listarTodos();
    }

    int cantidad() {
        return arch.cantidadRegistros();
    }

    bool borrar(int pos) {
        return arch.borrarRegistro(pos);
    }
};

#endif // ARCHIVOMEDICO_H_INCLUDED
