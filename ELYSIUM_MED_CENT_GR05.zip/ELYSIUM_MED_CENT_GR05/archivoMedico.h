#ifndef ARCHIVOMEDICO_H_INCLUDED
#define ARCHIVOMEDICO_H_INCLUDED

#include "Archivo.h"
#include "Medico.h"

class ArchivoMedico {
private:
    Archivo<Medico> arch;
public:
    ArchivoMedico() : arch("medicos.dat") {}

    bool guardar(const Medico& m) {
        return arch.guardar(m);
    }

    void listarTodos() {
        arch.listarTodos();
    }

    int cantidad() {
        return arch.cantidadRegistros();
    }

    bool leer(Medico& m, int pos) {
        return arch.leer(m, pos);
    }
    bool borrar(int pos) {
        Medico objVacio;
        FILE* p = fopen("medicos.dat", "rb+");
        if (p == NULL) return false;
        fseek(p, pos * sizeof(Medico), SEEK_SET);
        bool ok = fwrite(&objVacio, sizeof(Medico), 1, p);
        fclose(p);
        return ok;
    }
};

#endif // ARCHIVOMEDICO_H_INCLUDED
