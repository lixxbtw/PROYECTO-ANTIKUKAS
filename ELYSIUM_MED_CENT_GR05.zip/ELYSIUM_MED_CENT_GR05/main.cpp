#include <iostream>
#include <cstdlib>
#include "Archivo.h"
#include "Medico.h"
#include "Paciente.h"
#include "Turno.h"
#include "Consultorio.h"
#include "rlutil.h"

using namespace std;
/*
// Prototipos de submen�s
void menuPacientes(Archivo<Paciente>& archPac);
void menuMedicos(Archivo<Medico>& archMed);
void menuConsultorios(Archivo<Consultorio>& archCons);
void menuTurnos(Archivo<Turno>& archTurn);


*/
