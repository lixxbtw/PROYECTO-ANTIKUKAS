#include "Turno.h"
#include <iostream>
using namespace std;

Turno::Turno(): idTurno(0), legajoMedico(0), dniPaciente(0) {}

void Turno::cargar() {
    cout << "Legajo del medico: ";
    cin >> legajoMedico;
    cout << "DNI del paciente: ";
    cin >> dniPaciente;
    cout << "Ingrese fecha y hora del turno:" << endl;
    fecha.cargar();
}

void Turno::mostrar() const {
    cout << "Turno ID: " << idTurno
         << " | Legajo Medico: " << legajoMedico
         << " | DNI Paciente: " << dniPaciente << " | ";
    fecha.mostrar();
    cout << endl;
}
