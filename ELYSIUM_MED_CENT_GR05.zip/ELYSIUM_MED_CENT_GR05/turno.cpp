#include "Turno.h"
#include <iostream>
#include <cstring>
using namespace std;

Turno::Turno(): idTurno(0), dniPaciente(0) {
    especialidad[0] = '\0';
}

void Turno::cargar() {
    cout << endl;
    cout << "Las especialidades disponibles son: " << endl;
    cout << "1. Nutricion" << endl;
    cout << "2. Psiquiatria" << endl;
    cout << "3. Neurocirugia" << endl;
    cout << "4. Pediatria" << endl;
    cout << "5. Cardiologia" << endl;
    cout << endl;

    int opcion;
    cout << "Ingrese el numero de especialidad: ";
    cin >> opcion;

    while (opcion < 1 || opcion > 5) {
        cout << "Opcion invalida. Ingrese nuevamente (1-5): ";
        cin >> opcion;
    }

    switch (opcion) {
        case 1: strcpy(especialidad, "Nutricion"); break;
        case 2: strcpy(especialidad, "Psiquiatria"); break;
        case 3: strcpy(especialidad, "Neurocirugia"); break;
        case 4: strcpy(especialidad, "Pediatria"); break;
        case 5: strcpy(especialidad, "Cardiologia"); break;
    }

    cout << "DNI del paciente: ";
    cin >> dniPaciente;
    cout << "Ingrese fecha y hora del turno:" << endl;
    fecha.cargar();
}

void Turno::mostrar() const {
    cout << "Turno ID: " << idTurno
         << " | Paciente DNI: " << dniPaciente
         << " | Especialidad: " << especialidad << " | ";
    fecha.mostrar();
    cout << endl;
}
