#include "Hora.h"
#include <iostream>
using namespace std;

Hora::Hora() {
    hora = minutos = segundos = 0;
}

void Hora::cargar() {
    cout << "Hora (0-23): ";
    cin >> hora;
    cout << "Minutos (0-59): ";
    cin >> minutos;
    cout << "Segundos (0-59): ";
    cin >> segundos;
}

void Hora::mostrar() const {
    if (hora < 10) cout << '0';
    cout << hora << ':';
    if (minutos < 10) cout << '0';
    cout << minutos << ':';
    if (segundos < 10) cout << '0';
    cout << segundos;
}
