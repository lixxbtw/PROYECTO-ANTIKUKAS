#include "Hora.h"
#include <iostream>
using namespace std;

Hora::Hora() {
    hora = 0;
    minutos = 0;
    segundos = 0;
}

void Hora::cargar() {
    cout << "Hora (8-16): ";
    cin >> hora;

    while (hora < 8 || hora > 16) {
        cout << "Hora invalida. Debe estar entre 8 y 16." << endl;
        cout << "Hora (8-16): ";
        cin >> hora;
    }

    cout << "Minutos (0-59): ";
    cin >> minutos;
    while (minutos < 0 || minutos > 59) {
        cout << "Minutos invalidos. Deben estar entre 0 y 59." << endl;
        cout << "Minutos (0-59): ";
        cin >> minutos;
    }

    cout << "Segundos (0-59): ";
    cin >> segundos;
    while (segundos < 0 || segundos > 59) {
        cout << "Segundos invalidos. Deben estar entre 0 y 59." << endl;
        cout << "Segundos (0-59): ";
        cin >> segundos;
    }
}

void Hora::mostrar() const {
    if (hora < 10) cout << '0';
    cout << hora << ':';
    if (minutos < 10) cout << '0';
    cout << minutos << ':';
    if (segundos < 10) cout << '0';
    cout << segundos;
}
