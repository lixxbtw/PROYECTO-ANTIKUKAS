#include "Paciente.h"
#include <iostream>
#include <cstring>
#include <limits>
#include "rlutil.h"
using namespace std;

Paciente::Paciente() {
    telefono[0] = '\0';
}

void Paciente::cargar() {
    Persona::cargar(); //
    cout << "Telefono: ";
    cin.getline(telefono, 30);
}

void Paciente::mostrar() const {
    Persona::mostrar();
    cout << " | Telefono: " << telefono << endl;
}
