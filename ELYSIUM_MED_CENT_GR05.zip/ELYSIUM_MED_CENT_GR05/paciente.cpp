#include "Paciente.h"
#include <iostream>
#include <cstring>
#include <limits>
using namespace std;

Paciente::Paciente() {
    telefono[0] = '\0';
}

void Paciente::cargar() {
    Persona::cargar(); // carga nombre, apellido y DNI
    cout << "Telefono: ";
    cin.getline(telefono, 30); // usa getline para leer correctamente
}

void Paciente::mostrar() const {
    Persona::mostrar();
    cout << " | Telefono: " << telefono << endl;
}
