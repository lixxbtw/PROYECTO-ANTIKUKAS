#include "Paciente.h"
#include <iostream>
#include <cstring>
#include <limits>
#include "rlutil.h"
using namespace std;
using namespace rlutil;

Paciente::Paciente() {
    telefono[0] = '\0';
}

void Paciente::cargar() {
    system("cls");
    setBackgroundColor(BLUE);
    setColor(WHITE);

    int x = rlutil::tcols() / 2 - 20;
    int y = rlutil::trows() / 2 - 3;

    rlutil::locate(x, y);
    cout << "======================================" << endl;
    rlutil::locate(x, y + 1);
    cout << "          CARGA DE PACIENTE" << endl;
    rlutil::locate(x, y + 2);
    cout << "======================================" << endl;

    Persona::cargar();

    rlutil::locate(x, y + 7);
    cout << "Telefono: ";
    cin.getline(telefono, 30);
}

void Paciente::mostrar() const {
    cout << "----------------------------------------" << endl;
    Persona::mostrar();
    cout << " | Telefono: " << telefono << endl;
}
