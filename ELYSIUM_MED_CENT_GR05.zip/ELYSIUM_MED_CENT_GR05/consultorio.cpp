#include "Consultorio.h"
#include <iostream>
#include <cstring>
using namespace std;

Consultorio::Consultorio(): id(0) {
    nombre[0] = '\0';
    especialidad[0] = '\0';
}

void Consultorio::cargar() {
    cout << "ID Consultorio: "; cin >> id;
    cout << "Nombre Consultorio: "; cin >> nombre;
    cout << "Especialidad: "; cin >> especialidad;
}

void Consultorio::mostrar() const {
    cout << "ID: " << id << " | " << nombre << " | Esp: " << especialidad << endl;
}
