#include "Fecha.h"
#include <iostream>
using namespace std;

Fecha::Fecha() {
    dia = mes = anio = 0;
}

void Fecha::cargar() {
    cout << "Dia: ";
    cin >> dia;
    cout << "Mes: ";
    cin >> mes;
    cout << "Anio: ";
    cin >> anio;
    cout << "Ingrese hora:" << endl;
    hora.cargar();
}

void Fecha::mostrar() const {
    if (dia < 10) cout << '0';
    cout << dia << '/';
    if (mes < 10) cout << '0';
    cout << mes << '/';
    cout << anio << ' ';
    hora.mostrar();
}
