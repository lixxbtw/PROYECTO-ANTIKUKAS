#include "Fecha.h"
#include <iostream>
using namespace std;

Fecha::Fecha() {
    dia = 0;
    mes = 0;
    anio = 0;
    hora.hora = 0;
    hora.minutos = 0;
    hora.segundos = 0;
}

void Fecha::cargar() {
    cout << "Dia: ";
    cin >> dia;
    cout << "Mes: ";
    cin >> mes;
    cout << "Anio: ";
    cin >> anio;


    do {
        cout << "Hora (entre 8 y 16): ";
        cin >> hora.hora;
        if (hora.hora < 8 || hora.hora > 16) {
            cout << "Hora invalida. Debe estar entre 8 y 16." << endl;
        }
    } while (hora.hora < 8 || hora.hora > 16);


    cout << "Seleccione minutos (0, 15, 30 o 45): ";
    do {
        cin >> hora.minutos;
        if (hora.minutos != 0 && hora.minutos != 15 &&
            hora.minutos != 30 && hora.minutos != 45) {
            cout << "Valor invalido. Solo se permiten 0, 15, 30 o 45: ";
        }
    } while (hora.minutos != 0 && hora.minutos != 15 &&
             hora.minutos != 30 && hora.minutos != 45);

    hora.segundos = 0;
}

void Fecha::mostrar() const {
    if (dia < 10) cout << '0';
    cout << dia << '/';
    if (mes < 10) cout << '0';
    cout << mes << '/';
    cout << anio << ' ';
    if (hora.hora < 10) cout << '0';
    cout << hora.hora << ':';
    if (hora.minutos < 10) cout << '0';
    cout << hora.minutos;
}
