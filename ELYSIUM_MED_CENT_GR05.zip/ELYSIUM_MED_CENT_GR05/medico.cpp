#include "Medico.h"
#include <iostream>
#include <cstring>
using namespace std;

Medico::Medico() {
    legajo = 0;
    especialidad[0] = '\0';
}

void Medico::cargar() {
    Persona::cargar();
    cout << "Legajo: ";
    cin >> legajo;
    cout << "Especialidad: ";
    cin >> especialidad;
}

void Medico::mostrar() const {
    Persona::mostrar();
    cout << " | Legajo: " << legajo
         << " | Especialidad: " << especialidad << endl;
}
