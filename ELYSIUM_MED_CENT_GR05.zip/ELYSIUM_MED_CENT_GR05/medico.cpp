#include "Medico.h"
#include <iostream>
#include <cstring>
#include "rlutil.h"
using namespace std;
using namespace rlutil;

Medico::Medico() {
    legajo = 0;
    especialidad[0] = '\0';
    activo = true;
}

void Medico::cargar() {
    system("cls");
    setBackgroundColor(BLUE);
    setColor(WHITE);

    int x = rlutil::tcols() / 2 - 20;
    int y = rlutil::trows() / 2 - 4;

    rlutil::locate(x, y);
    cout << "======================================" << endl;
    rlutil::locate(x, y + 1);
    cout << "          CARGA DE MEDICO" << endl;
    rlutil::locate(x, y + 2);
    cout << "======================================" << endl;

    rlutil::locate(x, y + 4);
    cout << "Nombre: ";
    cin >> nombre;
    rlutil::locate(x, y + 5);
    cout << "Apellido: ";
    cin >> apellido;

    rlutil::locate(x, y + 7);
    cout << "Seleccione la especialidad:" << endl;
    rlutil::locate(x, y + 8);
    cout << "1. Nutricion" << endl;
    rlutil::locate(x, y + 9);
    cout << "2. Psiquiatria" << endl;
    rlutil::locate(x, y + 10);
    cout << "3. Neurocirugia" << endl;
    rlutil::locate(x, y + 11);
    cout << "4. Pediatria" << endl;
    rlutil::locate(x, y + 12);
    cout << "5. Cardiologia" << endl;

    int opcion;
    rlutil::locate(x, y + 14);
    cout << "Ingrese opcion (1-5): ";
    cin >> opcion;

    while (opcion < 1 || opcion > 5) {
        rlutil::locate(x, y + 15);
        cout << "Opcion invalida. Reintente: ";
        cin >> opcion;
    }

    switch (opcion) {
        case 1: strcpy(especialidad, "Nutricion"); break;
        case 2: strcpy(especialidad, "Psiquiatria"); break;
        case 3: strcpy(especialidad, "Neurocirugia"); break;
        case 4: strcpy(especialidad, "Pediatria"); break;
        case 5: strcpy(especialidad, "Cardiologia"); break;
    }

    activo = true;
}

void Medico::mostrar() const {
    cout << "----------------------------------------" << endl;
    cout << "Legajo: " << legajo << endl;
    cout << "Nombre: " << nombre << " " << apellido << endl;
    cout << "Especialidad: " << especialidad << endl;
    cout << "Estado: " << (activo ? "Activo" : "Inactivo") << endl;
}
