#include "Medico.h"
#include <iostream>
#include <cstring>
using namespace std;

Medico::Medico() {
    idMedico = 0;
    legajo = 0;
    especialidad[0] = '\0';
    activo = true;
}

void Medico::cargar() {
    Persona::cargar();

    cout << "Legajo del medico: ";
    cin >> legajo;

    cout << endl;
    cout << "Seleccione la especialidad:" << endl;
    cout << "1. Nutricion" << endl;
    cout << "2. Psiquiatria" << endl;
    cout << "3. Neurocirugia" << endl;
    cout << "4. Pediatria" << endl;
    cout << "5. Cardiologia" << endl;
    cout << endl;

    int opcion;
    cout << "Ingrese opcion (1-5): ";
    cin >> opcion;

    while (opcion < 1 || opcion > 5) {
        cout << "Opcion invalida. Reintente: ";
        cin >> opcion;
    }

    switch (opcion) {
        case 1: strcpy(especialidad, "Nutricion"); break;
        case 2: strcpy(especialidad, "Psiquiatria"); break;
        case 3: strcpy(especialidad, "Neurocirugia"); break;
        case 4: strcpy(especialidad, "Pediatria"); break;
        case 5: strcpy(especialidad, "Cardiologia"); break;
    }

    activo = true;
}

void Medico::mostrar() const {

    cout << "----------------------------------------" << endl;
    cout << "Nombre: " << nombre << " " << apellido << endl;
    cout << "ID: " << idMedico << " | Legajo: " << legajo << endl;
    cout << "Especialidad: " << especialidad << endl;
    cout << "Estado: " << (activo ? "Activo" : "Inactivo") << endl;
}
