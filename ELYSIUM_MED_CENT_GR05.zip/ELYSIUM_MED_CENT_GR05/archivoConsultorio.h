#ifndef ARCHIVOCONSULTORIO_H_INCLUDED
#define ARCHIVOCONSULTORIO_H_INCLUDED

#include "Archivo.h"
#include "Consultorio.h"

class ArchivoConsultorio {
private:
    Archivo<Consultorio> arch;
public:
    ArchivoConsultorio() : arch("consultorios.dat") {}

    bool guardar(const Consultorio& c) {
        return arch.guardar(c);
    }

    void listarTodos() {
        arch.listarTodos();
    }

    int cantidad() {
        return arch.cantidadRegistros();
    }

    bool borrar(int pos) {
        return arch.borrarRegistro(pos);
    }
};

#endif // ARCHIVOCONSULTORIO_H_INCLUDED
