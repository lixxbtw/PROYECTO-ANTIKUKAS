#ifndef ARCHIVOTURNO_H_INCLUDED
#define ARCHIVOTURNO_H_INCLUDED

#include "Archivo.h"
#include "Turno.h"

class ArchivoTurno {
private:
    Archivo<Turno> arch;
public:
    ArchivoTurno() : arch("turnos.dat") {}

    bool guardar(const Turno& t) {
        return arch.guardar(t);
    }

    void listarTodos() {
        arch.listarTodos();
    }

    int cantidad() {
        return arch.cantidadRegistros();
    }

    bool borrar(int pos) {
        return arch.borrarRegistro(pos);
    }
};

#endif // ARCHIVOTURNO_H_INCLUDED
