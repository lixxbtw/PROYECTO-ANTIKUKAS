#ifndef ARCHIVOPACIENTE_H_INCLUDED
#define ARCHIVOPACIENTE_H_INCLUDED

#include "Archivo.h"
#include "Paciente.h"

class ArchivoPaciente {
private:
    Archivo<Paciente> arch;
public:
    ArchivoPaciente() : arch("pacientes.dat") {}

    bool guardar(const Paciente& p) {
        return arch.guardar(p);
    }

    void listarTodos() {
        arch.listarTodos();
    }

    int cantidad() {
        return arch.cantidadRegistros();
    }

    bool borrar(int pos) {
        return arch.borrarRegistro(pos);
    }
};

#endif // ARCHIVOPACIENTE_H_INCLUDED
