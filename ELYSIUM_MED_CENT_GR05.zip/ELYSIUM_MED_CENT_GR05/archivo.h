#ifndef ARCHIVO_H_INCLUDED
#define ARCHIVO_H_INCLUDED

#include <cstdio>
#include <cstring>
#include <iostream>
using namespace std;

template <class T>
class Archivo {
private:
    char nombre[30];
public:
    Archivo(const char* n = "") {
        nombre[0] = '\0';
        if (n) strncpy(nombre, n, sizeof(nombre)-1);
    }

    bool guardar(const T& reg) {
        FILE* p = fopen(nombre, "ab");
        if (!p) return false;
        bool ok = fwrite(&reg, sizeof(T), 1, p);
        fclose(p);
        return ok;
    }

    bool leer(T& reg, int pos) {
        FILE* p = fopen(nombre, "rb");
        if (!p) return false;
        fseek(p, pos * sizeof(T), SEEK_SET);
        bool ok = fread(&reg, sizeof(T), 1, p);
        fclose(p);
        return ok;
    }

    int cantidadRegistros() {
        FILE* p = fopen(nombre, "rb");
        if (!p) return 0;
        fseek(p, 0, SEEK_END);
        long bytes = ftell(p);
        fclose(p);
        return (bytes > 0 ? bytes / sizeof(T) : 0);
    }

    void listarTodos() {
        int n = cantidadRegistros();
        T obj;
        cout << "---- Total: " << n << " ----" << endl;
        for (int i = 0; i < n; ++i) {
            if (leer(obj, i)) {
                cout << i + 1 << ". ";
                obj.mostrar();
            }
        }
    }


    bool borrarRegistro(int posicion) {
        FILE* p = fopen(nombre, "rb");
        if (!p) return false;
        FILE* temp = fopen("temp.dat", "wb");
        if (!temp) { fclose(p); return false; }

        T obj;
        int pos = 0;
        while (fread(&obj, sizeof(T), 1, p) == 1) {
            if (pos != posicion) fwrite(&obj, sizeof(T), 1, temp);
            pos++;
        }

        fclose(p);
        fclose(temp);
        remove(nombre);
        rename("temp.dat", nombre);
        return true;
    }
};

#endif // ARCHIVO_H_INCLUDED
