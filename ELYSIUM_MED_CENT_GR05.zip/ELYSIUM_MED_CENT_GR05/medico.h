#ifndef MEDICO_H_INCLUDED
#define MEDICO_H_INCLUDED

#include "Persona.h"

class Medico : public Persona {
private:
    int legajo;
    char especialidad[30];
    bool activo;

public:
    Medico();
    void cargar();
    void mostrar() const;

    void setLegajo(int l) { legajo = l; }
    int getLegajo() const { return legajo; }

    const char* getEspecialidad() const { return especialidad; }

    bool getActivo() const { return activo; }
    void setActivo(bool estado) { activo = estado; }

    void desactivar() { activo = false; }   // 👈 ESTA LINEA ES LA CLAVE
};

#endif // MEDICO_H_INCLUDED
