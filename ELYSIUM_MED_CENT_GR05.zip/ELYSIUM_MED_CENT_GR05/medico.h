#ifndef MEDICO_H_INCLUDED
#define MEDICO_H_INCLUDED

#include "Persona.h"

class Medico : public Persona {
private:
    int idMedico;
    int legajo;
    char especialidad[30];
    bool activo;
public:
    Medico();

    void cargar();
    void mostrar() const;

    void setID(int id) { idMedico = id; }
    int getID() const { return idMedico; }

    void setLegajo(int l) { legajo = l; }
    int getLegajo() const { return legajo; }

    const char* getEspecialidad() const { return especialidad; }

    bool getActivo() const { return activo; }
    void setActivo(bool estado) { activo = estado; }
};

#endif // MEDICO_H_INCLUDED
