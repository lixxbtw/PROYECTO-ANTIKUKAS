#ifndef MEDICO_H_INCLUDED
#define MEDICO_H_INCLUDED

#include "Persona.h"

class Medico : public Persona {
private:
    int legajo;
    char especialidad[30];
public:
    Medico();
    void cargar();
    void mostrar() const;
    int getLegajo() const { return legajo; }
};

#endif // MEDICO_H_INCLUDED
