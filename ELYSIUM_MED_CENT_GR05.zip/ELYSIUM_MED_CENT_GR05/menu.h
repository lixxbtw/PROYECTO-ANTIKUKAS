#ifndef MENU_H_INCLUDED
#define MENU_H_INCLUDED

void menuPrincipal();
void menuPacientes();
void menuMedicos();
void menuConsultorios();
void menuTurnos();

#endif // MENU_H_INCLUDED
