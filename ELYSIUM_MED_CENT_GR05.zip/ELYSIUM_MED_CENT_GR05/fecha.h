#ifndef FECHA_H_INCLUDED
#define FECHA_H_INCLUDED

#include <iostream>
using namespace std;

class Fecha {
private:
    int dia, mes, anio;

public:
    struct Hora {
        int hora;
        int minutos;
        int segundos;
    };

private:
    Hora hora;

public:
    Fecha();
    void cargar();
    void mostrar() const;

    int getDia() const { return dia; }
    int getMes() const { return mes; }
    int getAnio() const { return anio; }
    int getHoraVal() const { return hora.hora; }
    int getMinutoVal() const { return hora.minutos; }
};

#endif // FECHA_H_INCLUDED
