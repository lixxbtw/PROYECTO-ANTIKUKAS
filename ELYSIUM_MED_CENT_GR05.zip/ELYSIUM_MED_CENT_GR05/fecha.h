#ifndef FECHA_H_INCLUDED
#define FECHA_H_INCLUDED

#include "Hora.h"

class Fecha {
private:
    int dia, mes, anio;
    Hora hora;
public:
    Fecha();
    void cargar();
    void mostrar() const;
};

#endif // FECHA_H_INCLUDED

