#ifndef FUNCIONES_H_INCLUDED
#define FUNCIONES_H_INCLUDED

#include "Archivo.h"

// Funci�n template de b�squeda por clave (opcional, �til para los men�s)
template <typename T, typename KeyGetter>
int buscarPorClave(const char* nombreArchivo, KeyGetter getClave, int valorBuscado) {
    Archivo<T> arch(nombreArchivo);
    int n = arch.cantidadRegistros();
    T obj;
    for (int i = 0; i < n; i++) {
        if (arch.leer(obj, i) && getClave(obj) == valorBuscado) return i;
    }
    return -1;
}

#endif // FUNCIONES_H_INCLUDED
