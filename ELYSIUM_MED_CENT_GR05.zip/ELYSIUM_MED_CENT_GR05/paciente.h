#ifndef PACIENTE_H_INCLUDED
#define PACIENTE_H_INCLUDED

#include "Persona.h"

class Paciente : public Persona {
private:
    char telefono[30];
public:
    Paciente();
    void cargar();
    void mostrar() const;
};

#endif // PACIENTE_H_INCLUDED
