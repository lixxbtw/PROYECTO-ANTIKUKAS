#include "Funciones.h"
#include <iostream>
#include <limits>
using namespace std;

int leerEntero(const char* mensaje) {
    int valor;
    while (true) {
        cout << mensaje;
        if (cin >> valor) return valor;
        cout << "Entrada invalida. Intente nuevamente." << endl;
        cin.clear();
        cin.ignore(numeric_limits<streamsize>::max(), '\n');
    }
}
