#include <fstream>
#include "Archivos.h"

using namespace std;
/**
template <typename T>
bool guardarRegistro(const char* nombreArchivo, const T& obj) {
    ofstream file(nombreArchivo, ios::app | ios::binary);
    if (!file) return false;
    file.write(reinterpret_cast<const char*>(&obj), sizeof(T));
    file.close();
    return true;
}

template <typename T>
bool leerRegistro(const char* nombreArchivo, T& obj, int pos) {
    ifstream file(nombreArchivo, ios::binary);
    if (!file) return false;
    file.seekg(pos * sizeof(T), ios::beg);
    file.read(reinterpret_cast<char*>(&obj), sizeof(T));
    file.close();
    return true;
}
*/

void limpiarPantalla() {
    system("cls");
}

void pausa() {
    system("pause");
}

