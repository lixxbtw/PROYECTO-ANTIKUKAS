#include <iostream>
#include <cstdio>      // fopen, fread, fwrite, fseek, fclose
#include <cstring>     // strcmp barbi
#include "Medico.h"

using namespace std;

//global
const char* ARCHIVO_MEDICOS = "medicos.dat";

void Medico::cargar() {
    cout << "Ingrese nombre: ";
    cin >> nombre;
    cout << "Ingrese apellido: ";
    cin >> apellido;
    cout << "Las especialidades existentes son: " << endl;
    cout << "Nutricion" << endl;
    cout << "Psiquiatria" << endl;
    cout << "Neurocirugia"<< endl;
    cout << "Pediatria" << endl;
    cout << "Cardiologia" << endl;
    cout << "Ingrese especialidad: ";
    cin >> especialidad;
    activo = true; // alta l�gica
}

void Medico::mostrar() const {
    cout << "Dr/a. " << nombre << " " << apellido << " - " << especialidad << endl;
    cout << "Estado: " << (activo ? "Activo" : "Inactivo") << endl;
    cout << "---------------------------------------" << endl;
}

bool Medico::guardarEnArchivo() const {
    FILE *p = fopen(ARCHIVO_MEDICOS, "ab");
    if (p == NULL) return false;
    bool ok = fwrite(this, sizeof(Medico), 1, p);
    fclose(p);
    return ok;
}

bool Medico::leerDeArchivo(int pos) {
    FILE *p = fopen(ARCHIVO_MEDICOS, "rb");
    if (p == NULL) return false;
    fseek(p, pos * sizeof(Medico), SEEK_SET);
    bool ok = fread(this, sizeof(Medico), 1, p);
    fclose(p);
    return ok;
}

void altaMedico() {
    Medico m;
    m.cargar();
    if (m.guardarEnArchivo())
        cout << "Medico guardado correctamente" << endl;
    else
        cout << "Error al guardar el medico" << endl;
    system("pause");
}

void listarMedicos() {
    FILE *p = fopen("medicos.dat", "rb");
    if (p == NULL) {
        cout << "No se puede abrir el archivo" << endl;
        system("pause");
        return;
    }

    Medico m;
    int i = 0;
    while (fread(&m, sizeof(Medico), 1, p) == 1) {
        cout << "Medico #" << ++i << endl;
        m.mostrar();
    }

    if (i == 0)
        cout << "No hay medicos cargados" << endl;

    fclose(p);
    system("pause");
}

void buscarMedicoPorEspecialidad() {
    char especialidadBuscada[30];
    cout << "Las especialidades existentes son: " << endl;
    cout << endl; cout << "Nutricion" << endl;
    cout << "Psiquiatria" << endl;
    cout << "Neurocirugia"<< endl;
    cout << "Pediatria" << endl;
    cout << "Cardiologia" << endl;
    cout << endl;
    cout << "Ingrese especialidad a buscar: ";
    cin >> especialidadBuscada;

    FILE *p = fopen("medicos.dat", "rb");
    if (p == NULL) {
        cout << "No se puede abrir el archivo" << endl;
        system("pause");
        return;
    }

    Medico m;
    bool encontrado = false;

    while (fread(&m, sizeof(Medico), 1, p) == 1) {
        if (m.getActivo()) {
            // Comparaci�n insensible a may�sculas/min�sculas
            if (strcasecmp(m.getEspecialidad(), especialidadBuscada) == 0) {
                cout << endl;
                cout << "--------------------------------------" << endl;
                cout << "Medico encontrado:" << endl;
                m.mostrar();
                encontrado = true;
            }
        }
    }

    if (!encontrado)
        cout << endl;
        cout << "No se encontraron medicos con esa especialidad" << endl;

    fclose(p);
    system("pause");
}
void bajaMedico() {
    char nombreBuscado[30], apellidoBuscado[30];
    cout << "Para dar derlo de baja debe: " << endl;
    cout << endl;
    cout << "Ingresar nombre: ";
    cin >> nombreBuscado;
    cout << "Ingresar apellido: ";
    cin >> apellidoBuscado;

    FILE *p = fopen("medicos.dat", "rb+");
    if (p == NULL) {
        cout << endl;
        cout << "No se puede abrir el archivo" << endl;
        system("pause");
        return;
    }

    Medico m;
    bool encontrado = false;
    int pos = 0;

    while (fread(&m, sizeof(Medico), 1, p) == 1) {
        if (m.getActivo() &&
            strcmp(m.getNombre(), nombreBuscado) == 0 &&
            strcmp(m.getApellido(), apellidoBuscado) == 0) {

            m.setActivo(false);
            fseek(p, pos * sizeof(Medico), SEEK_SET);
            fwrite(&m, sizeof(Medico), 1, p);
            cout << endl;
            cout << "Medico dado de baja correctamente" << endl;
            encontrado = true;
            break;
        }
        pos++;
    }

    if (!encontrado)
        cout << "No se encontro el medico o ya estaba dado de baja" << endl;

    fclose(p);
    system("pause");
}

void menuMedicos() {
    int opcion;
    do {
        system("cls");
        cout << "======================================" << endl;
        cout << "     GESTION DE MEDICOS" << endl;
        cout << "======================================" << endl;
        cout << endl;
        cout << "1. Alta de Medico" << endl;
        cout << "2. Listar Medicos" << endl;
        cout << "3. Buscar por Especialidad" << endl;
        cout << "4. Baja de Medico" << endl;
        cout << "0. Volver" << endl;
        cout << endl;
        cout << "--------------------------------------" << endl;
        cout << "Seleccione una opcion: ";
        cin >> opcion;
        system("cls");

        switch (opcion) {
            case 1: altaMedico();
            break;
            case 2: listarMedicos();
            break;
            case 3: buscarMedicoPorEspecialidad();
            break;
            case 4: bajaMedico();
            break;
            case 0:
            break;
            default: cout << "Opcion incorrecta" << endl;
            system("pause");
        }
    } while (opcion != 0);
}
