#ifndef MEDICO_H_INCLUDED
#define MEDICO_H_INCLUDED

class Medico {
private:
    char nombre[30];
    char apellido[30];
    char especialidad[30];
    bool activo;

public:

    // M�todos de carga, muestra y estado
    void cargar();
    void mostrar() const;
    bool getActivo() const {
         return activo; }

    // M�todos get para buscar o comparar
    const char* getNombre() const {
        return nombre; }
    const char* getApellido() const {
        return apellido; }
    const char* getEspecialidad() const {
        return especialidad; }

    // M�todo para cambiar estado (puntero this)
    void setActivo(bool estado) {
        this->activo = estado; }

    // Operaciones de archivo
    bool guardarEnArchivo() const;
    bool leerDeArchivo(int pos);
};

void menuMedicos();
void altaMedico();
void listarMedicos();
void buscarMedicoPorEspecialidad();
void bajaMedico();

#endif // MEDICO_H_INCLUDED

