#include <iostream>
#include <fstream>
#include <cstring>
#include "Turno.h"

using namespace std;

const char* ARCHIVO_TURNOS = "turnos.dat";

// === M�TODOS DE LA CLASE ===

void Turno::cargar() {
    cout << "Ingrese ID del turno: ";
    cin >> id;
    cout << "Ingrese DNI del paciente: ";
    cin >> dniPaciente;
    cout << "Ingrese ID del medico: ";
    cin >> idMedico;
    cout << "Ingrese fecha (dd/mm/aaaa): ";
    cin >> fecha;
    cout << "Ingrese hora (HH:MM): ";
    cin >> hora;
    activo = true;
}

void Turno::mostrar() const {
    cout << "-------------------------------------" << endl;
    cout << "ID Turno: " << id << endl;
    cout << "DNI Paciente: " << dniPaciente << endl;
    cout << "ID M�dico: " << idMedico << endl;
    cout << "Fecha: " << fecha << endl;
    cout << "Hora: " << hora << endl;
    cout << "Estado: " << (activo ? "Activo" : "Cancelado") << endl;
}

// === M�TODOS DE ARCHIVO ===

bool Turno::guardarEnArchivo() const {
    ofstream file(ARCHIVO_TURNOS, ios::app | ios::binary);
    if (!file) return false;
    file.write(reinterpret_cast<const char*>(this), sizeof(Turno));
    file.close();
    return true;
}

bool Turno::leerDeArchivo(int pos) {
    ifstream file(ARCHIVO_TURNOS, ios::binary);
    if (!file) return false;
    file.seekg(pos * sizeof(Turno), ios::beg);
    file.read(reinterpret_cast<char*>(this), sizeof(Turno));
    file.close();
    return file.good();
}

// === MEN� PRINCIPAL ===

void menuTurnos() {
    int opcion;
    do {
        system("cls");
        cout << "=== GESTION DE TURNOS ===" << endl;
        cout << "1. Alta de Turno" << endl;
        cout << "2. Listar Turnos" << endl;
        cout << "3. Buscar Turno por Fecha" << endl;
        cout << "4. Cancelar Turno" << endl;
        cout << "0. Volver" << endl;
        cout << "Seleccione una opcion: ";
        cin >> opcion;
        system("cls");

        switch (opcion) {
            case 1: altaTurno(); break;
            case 2: listarTurnos(); break;
            case 3: buscarTurnoPorFecha(); break;
            case 4: bajaTurno(); break;
            case 0: break;
            default:
                cout << "Opcion incorrecta." << endl;
                system("pause");
        }
    } while (opcion != 0);
}

// === FUNCIONALIDADES ===

void altaTurno() {
    Turno t;
    t.cargar();
    if (t.guardarEnArchivo())
        cout << "Turno guardado correctamente." << endl;
    else
        cout << "Error al guardar el turno." << endl;
    system("pause");
}

void listarTurnos() {
    ifstream file(ARCHIVO_TURNOS, ios::binary);
    if (!file) {
        cout << "No se puede abrir el archivo." << endl;
        system("pause");
        return;
    }

    Turno t;
    int i = 0;
    while (file.read(reinterpret_cast<char*>(&t), sizeof(Turno))) {
        if (t.getActivo()) {
            cout << "Turno #" << ++i << endl;
            t.mostrar();
        }
    }

    if (i == 0)
        cout << "No hay turnos activos." << endl;

    file.close();
    system("pause");
}

void buscarTurnoPorFecha() {
    char fechaBuscada[11];
    cout << "Ingrese fecha a buscar (dd/mm/aaaa): ";
    cin >> fechaBuscada;

    ifstream file(ARCHIVO_TURNOS, ios::binary);
    if (!file) {
        cout << "No se puede abrir el archivo." << endl;
        system("pause");
        return;
    }

    Turno t;
    bool encontrado = false;

    while (file.read(reinterpret_cast<char*>(&t), sizeof(Turno))) {
        if (t.getActivo() && strcmp(t.getFecha(), fechaBuscada) == 0) {
            t.mostrar();
            encontrado = true;
        }
    }

    if (!encontrado)
        cout << "No hay turnos para esa fecha." << endl;

    file.close();
    system("pause");
}

void bajaTurno() {
    int idBuscado;
    cout << "Ingrese ID del turno a cancelar: ";
    cin >> idBuscado;

    fstream file(ARCHIVO_TURNOS, ios::in | ios::out | ios::binary);
    if (!file) {
        cout << "No se puede abrir el archivo." << endl;
        system("pause");
        return;
    }

    Turno t;
    bool encontrado = false;
    int pos = 0;

    while (file.read(reinterpret_cast<char*>(&t), sizeof(Turno))) {
        if (t.getID() == idBuscado && t.getActivo()) {
            t.setActivo(false);
            file.seekp(pos * sizeof(Turno), ios::beg);
            file.write(reinterpret_cast<char*>(&t), sizeof(Turno));
            cout << "Turno cancelado correctamente." << endl;
            encontrado = true;
            break;
        }
        pos++;
    }

    if (!encontrado)
        cout << "No se encontro el turno o ya estaba cancelado." << endl;

    file.close();
    system("pause");
}
