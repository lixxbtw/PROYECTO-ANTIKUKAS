#ifndef TURNO_H
#define TURNO_H

#include <iostream>
using namespace std;

class Turno {
private:
    int id;
    int dniPaciente;
    int idMedico;
    // Especialidades predeterminadas
    int idEspecialidad;
    char fecha[11];   // formato: dd/mm/aaaa
    char hora[6];     // formato: HH:MM
    bool activo;      // true = activo, false = cancelado

public:
    // --- M�TODOS PRINCIPALES ---
    void cargar();
    void mostrar() const;

    // --- GETTERS ---
    int getID() const { return id; }
    int getDNIPaciente() const { return dniPaciente; }
    int getIDMedico() const { return idMedico; }
    const char* getFecha() const { return fecha; }
    const char* getHora() const { return hora; }
    bool getActivo() const { return activo; }

    // --- SETTERS ---
    void setActivo(bool estado) { activo = estado; }

    // --- ARCHIVO ---
    bool guardarEnArchivo() const;
    bool leerDeArchivo(int pos);
};

// --- FUNCIONES DEL MEN� ---
void menuTurnos();
void altaTurno();
void listarTurnos();
void buscarTurnoPorFecha();
void bajaTurno();



#endif
