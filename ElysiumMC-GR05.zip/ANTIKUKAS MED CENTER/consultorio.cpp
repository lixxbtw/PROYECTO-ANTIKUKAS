#include <iostream>
#include <cstdio>      // fopen, fread, fwrite, fseek, fclose
#include <cstring>
#include "Consultorio.h"

using namespace std;

const char* ARCHIVO_CONSULTORIOS = "consultorios.dat";

void Consultorio::cargar() {
    cout << "Ingrese numero del consultorio: ";
    cin >> numero;
    cout << "Ingrese piso: ";
    cin >> piso;
    cout << "Ingrese especialidad: ";
    cin >> especialidad;
    activo = true;
}

void Consultorio::mostrar() const {
    cout << "---------------------------------------" << endl;
    cout << "Consultorio N�" << numero << " | Piso: " << piso
         << " | Especialidad: " << especialidad << endl;
    cout << "Estado: " << (activo ? "Activo" : "Inactivo") << endl;
}

bool Consultorio::guardarEnArchivo() const {
    FILE *p = fopen(ARCHIVO_CONSULTORIOS, "ab");
    if (p == NULL) return false;
    bool ok = fwrite(this, sizeof(Consultorio), 1, p);
    fclose(p);
    return ok;
}

bool Consultorio::leerDeArchivo(int pos) {
    FILE *p = fopen(ARCHIVO_CONSULTORIOS, "rb");
    if (p == NULL) return false;
    fseek(p, pos * sizeof(Consultorio), SEEK_SET);
    bool ok = fread(this, sizeof(Consultorio), 1, p);
    fclose(p);
    return ok;
}

void menuConsultorios() {
    int opcion;
    do {
        system("cls");
        cout << "======================================" << endl;
        cout << "     MENU CONSULTORIOS" << endl;
        cout << "======================================" << endl;
        cout << endl;
        cout << "1. Alta de Consultorio" << endl;
        cout << "2. Listar Consultorios" << endl;
        cout << "3. Buscar por Especialidad" << endl;
        cout << "4. Buscar por Piso" << endl;
        cout << "5. Baja de Consultorio" << endl;
        cout << "0. Volver" << endl;
        cout << endl;
        cout << "--------------------------------------" << endl;
        cout << "Seleccione una opcion: ";
        cin >> opcion;

        switch (opcion) {
            case 1: altaConsultorio(); break;
            case 2: listarConsultorios(); break;
            case 3: buscarConsultorioPorEspecialidad(); break;
            case 4: buscarConsultorioPorPiso(); break;
            case 5: bajaConsultorio(); break;
            case 0: break;
            default:
                cout << "Opcion incorrecta" << endl;
                system("pause");
        }
    } while (opcion != 0);
}

void altaConsultorio() {
    Consultorio c;
    c.cargar();
    if (c.guardarEnArchivo())
        cout << "Consultorio guardado correctamente" << endl;
    else
        cout << "Error al guardar consultorio" << endl;
    system("pause");
}

void listarConsultorios() {
    FILE *p = fopen(ARCHIVO_CONSULTORIOS, "rb");
    if (p == NULL) {
        cout << "No se puede abrir el archivo" << endl;
        system("pause");
        return;
    }

    Consultorio c;
    int contador = 0;

    while (fread(&c, sizeof(Consultorio), 1, p) == 1) {
        cout << "Consultorio Nro." << ++contador << endl;
        c.mostrar();
    }

    if (contador == 0)
        cout << "No hay consultorios cargados" << endl;

    fclose(p);
    system("pause");
}

void buscarConsultorioPorEspecialidad() {
    char espBuscada[30];
    cout << "Ingrese especialidad a buscar: ";
    cin >> espBuscada;

    FILE *p = fopen(ARCHIVO_CONSULTORIOS, "rb");
    if (p == NULL) {
        cout << "No se puede abrir el archivo" << endl;
        system("pause");
        return;
    }

    Consultorio c;
    bool encontrado = false;

    while (fread(&c, sizeof(Consultorio), 1, p) == 1) {
        if (strcmp(c.getEspecialidad(), espBuscada) == 0 && c.getActivo()) {
            c.mostrar();
            encontrado = true;
        }
    }

    if (!encontrado)
        cout << "No se encontro ningun consultorio con esa especialidad" << endl;

    fclose(p);
    system("pause");
}

void buscarConsultorioPorPiso() {
    int pisoBuscado;
    cout << "Ingrese piso a buscar: ";
    cin >> pisoBuscado;

    FILE *p = fopen(ARCHIVO_CONSULTORIOS, "rb");
    if (p == NULL) {
        cout << "No se puede abrir el archivo" << endl;
        system("pause");
        return;
    }

    Consultorio c;
    bool encontrado = false;

    while (fread(&c, sizeof(Consultorio), 1, p) == 1) {
        if (c.getPiso() == pisoBuscado && c.getActivo()) {
            c.mostrar();
            encontrado = true;
        }
    }

    if (!encontrado)
        cout << "No se encontro ningun consultorio en ese piso" << endl;

    fclose(p);
    system("pause");
}

void bajaConsultorio() {
    int numeroBuscado;
    cout << "Ingrese numero del consultorio a dar de baja: ";
    cin >> numeroBuscado;

    FILE *p = fopen(ARCHIVO_CONSULTORIOS, "rb+");
    if (p == NULL) {
        cout << "No se puede abrir el archivo" << endl;
        system("pause");
        return;
    }

    Consultorio c;
    bool encontrado = false;
    int pos = 0;

    while (fread(&c, sizeof(Consultorio), 1, p) == 1) {
        if (c.getNumero() == numeroBuscado && c.getActivo()) {
            c.setActivo(false);
            fseek(p, pos * sizeof(Consultorio), SEEK_SET);
            fwrite(&c, sizeof(Consultorio), 1, p);
            cout << "Consultorio dado de baja correctamente." << endl;
            encontrado = true;
            break;
        }
        pos++;
    }

    if (!encontrado)
        cout << "No se encontro el consultorio o ya estaba inactivo" << endl;

    fclose(p);
    system("pause");
}
